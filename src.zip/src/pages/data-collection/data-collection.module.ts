import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DataCollection } from './data-collection';

@NgModule({
  declarations: [
    DataCollection,
  ],
  imports: [
    IonicPageModule.forChild(DataCollection),
  ],
})
export class DataCollectionPageModule {}
