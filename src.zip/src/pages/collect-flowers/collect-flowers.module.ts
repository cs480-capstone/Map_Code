import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CollectFlowers } from './collect-flowers';

@NgModule({
  declarations: [
    CollectFlowers,
  ],
  imports: [
    IonicPageModule.forChild(CollectFlowers),
  ],
})
export class CollectFlowersPageModule {}
